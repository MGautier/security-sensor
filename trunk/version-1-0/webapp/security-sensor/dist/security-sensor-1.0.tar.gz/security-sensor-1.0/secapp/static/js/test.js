// comment

/// comment

function test(){
alert("this is a test");

// More comments
}