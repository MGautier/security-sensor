from django.apps import AppConfig


# Aqui cargamos las aplicaciones que haran uso del proyecto django creado

# Author: Moises Gautier Gomez
# Proyecto fin de carrera - Ing. en Informatica
# Universidad de Granada

class SecappConfig(AppConfig):
    name = 'secapp'
